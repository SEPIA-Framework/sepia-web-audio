This was copied from https://github.com/xiph/speexdsp/tree/master/libspeexdsp
