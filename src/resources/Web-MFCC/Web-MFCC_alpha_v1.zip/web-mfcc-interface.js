//Web-MFCC Interface for SEPIA Web-Audio Processor
var WebMfccAnalyzer = function(options, initCallback){
	this.webMfcc = {};
	this.options = options || {};
	
	var onPrint = this.options.onInfo || this.options.onPrint || function(text){ console.log("WebMFCC print", text); };
	var onError = this.options.onError || this.options.onPrintErr || function(text){ console.error("WebMFCC printErr", text); };
	var onStatus = this.options.onStatusMessage || this.options.onSetStatus || function(text){ console.log("WebMFCC setStatus", text); };
	var skipStreamingInit = (this.options.skipStreamingInit != undefined)? this.options.skipStreamingInit : true;

	WebMFCC({
		print: function(text){
			if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ');
			onPrint(text);
		},
		printErr: function(text){
			if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ');
			onError(text);
		},
		setStatus: function(text){
			if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ');
			onStatus(text);
		},
		skipStreamingInit: skipStreamingInit
	})
	.then(function(Module){
		var WebMfcc = {
			webMfccModule: Module
			//getCoefficients: ...
		};
		
		//setup
		
		var tensorFlowLiteMfccs = Module.cwrap('tf_mfccs', 'number', 
			['number', 'number', 'number', 'number', 'number', 'number', 'number', 'number', 'number']);
		//(pcmPtr, lenPtr, sampleRate, windowSize, windowStride, upperFrequencyLimit, lowerFrequencyLimit, filterbankChannelCount, dctCoefficientCount);
		
		WebMfcc.getCoefficients = function(pcmSamples, sampleRate, windowSize, windowStride, 
				upperFrequencyLimit = 4000, lowerFrequencyLimit = 20, filterbankChannelCount = 40, dctCoefficientCount = 13){
			
			var pcmPtr = Module._malloc(8 * pcmSamples.length);
			var lenPtr = Module._malloc(4);

			for(let i=0; i<pcmSamples.length; i++) {
				Module.HEAPF64[pcmPtr/8 + i] = pcmSamples[i];
			}
			Module.HEAP32[lenPtr/4] = pcmSamples.length;

			var mfccsPtr = tensorFlowLiteMfccs(pcmPtr, lenPtr, sampleRate, windowSize, windowStride, 
					upperFrequencyLimit, lowerFrequencyLimit, filterbankChannelCount, dctCoefficientCount);
			var mfccsLen = Module.HEAP32[lenPtr >> 2];
			var audioMfccs = new Array(mfccsLen);

			for(let i=0; i<mfccsLen; i++){
				audioMfccs[i] = Module.HEAPF64[(mfccsPtr >> 3) + i];
			}

			Module._free(pcmPtr, lenPtr, mfccsPtr);

			return audioMfccs;
		}
		
		return WebMfcc;
	})
	.then(function(webMfcc){
		this.webMfcc = webMfcc;
		if (initCallback) initCallback(this.webMfcc);
	});
	//Module.setStatus('Downloading...');
}
